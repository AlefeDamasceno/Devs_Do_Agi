package br.com.devsdoagi.Maratonas.MiniHackaton2;

abstract class Investimento {
    private double valorInicial;

    public Investimento(){
        this.valorInicial = 0.0;
    }
    public Investimento(double valorInicial){
        this.valorInicial = valorInicial;
    }

    public double getValorInicial(){
        return valorInicial;
    }
    public void setValorInicial(double valorInicial){
        this.valorInicial = valorInicial;
    }

    public abstract double calcularRendimento();
}
