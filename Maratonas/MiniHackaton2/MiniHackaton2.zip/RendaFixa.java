package br.com.devsdoagi.Maratonas.MiniHackaton2;

public class RendaFixa extends Investimento{
    public RendaFixa(){
        super();
    }
    public RendaFixa(double valorInicial){
        super(valorInicial);
    }

    @Override
    public double calcularRendimento(){
        return getValorInicial() * 1.05;
    }
}
