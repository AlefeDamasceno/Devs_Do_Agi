package br.com.devsdoagi.Maratonas.MiniHackaton2;

public class RendaVariavel extends Investimento{
    public RendaVariavel(){
        super();
    }
    public RendaVariavel(double valorInicial){
        super(valorInicial);
    }

    @Override
    public double calcularRendimento(){
        return getValorInicial() * 1.1;
    }
}
